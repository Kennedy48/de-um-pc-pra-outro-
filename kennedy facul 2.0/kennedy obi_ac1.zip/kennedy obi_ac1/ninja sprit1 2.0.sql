use ac101202022;

select * from ninja ;
  select * from ninja order by clã desc;
  select nome  from ninja;
  select* from ninja where nome like '%r_';
  select* from ninja where nome like '%a'; 